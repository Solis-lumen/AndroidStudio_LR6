package com.example.lr6

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class ScrollViewDemoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.scrollview_demo)
    }

    fun buttonBackToMainActivityClick(view: View) {
        finish()
    }
}
