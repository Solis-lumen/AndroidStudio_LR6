package com.example.lr6

import android.os.Parcel
import android.os.Parcelable

data class Dessert(
    val dessertName: String,
    val dessertImgId: Int,
    var isSelected: Boolean = false
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readInt(),
        parcel.readByte() != 0.toByte()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(dessertName)
        parcel.writeInt(dessertImgId)
        parcel.writeByte(if (isSelected) 1 else 0)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Dessert> {
        override fun createFromParcel(parcel: Parcel): Dessert {
            return Dessert(parcel)
        }

        override fun newArray(size: Int): Array<Dessert?> {
            return arrayOfNulls(size)
        }
    }
}
