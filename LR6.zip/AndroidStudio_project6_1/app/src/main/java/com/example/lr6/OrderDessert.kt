package com.example.lr6

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class OrderDessert : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.order_dessert)

        // Отримання обраних десертів
        val selectedDesserts = intent.getParcelableArrayListExtra<Dessert>("selectedDesserts")

        // Відображення вибраних десертів у ListView
        val listView: ListView = findViewById(R.id.ListViewOrderedDessert)
        val dessertNames = selectedDesserts?.map { it.dessertName } ?: listOf()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, dessertNames)
        listView.adapter = adapter
    }

    fun buttonBackToMainActivityClick(view: View) {
        finish()
    }
}