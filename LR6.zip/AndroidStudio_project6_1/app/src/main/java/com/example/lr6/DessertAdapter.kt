package com.example.lr6

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DessertAdapter(val dessertList : ArrayList<Dessert>) : RecyclerView.Adapter<DessertAdapter.DishViewHolder>() {
    interface ViewHolderCheckboxListener {
        fun onCheckedChange (position: Int, isChecked: Boolean)
    }

    var callback: ViewHolderCheckboxListener? = null

    class DishViewHolder(itemView: View, checkboxListener: ViewHolderCheckboxListener?) : RecyclerView.ViewHolder(itemView) {
        val dessertImage : ImageView = itemView.findViewById(R.id.dessertImage)
        val dessertName : TextView = itemView.findViewById(R.id.dessertName)
        val dessertCheckBox : CheckBox = itemView.findViewById(R.id.checkBoxDessertToOrder)

        init {
            dessertCheckBox.setOnCheckedChangeListener {
                checkboxView, isChecked -> checkboxListener?.onCheckedChange(adapterPosition, isChecked)
            }
        }
    }

    fun getDessertByPosition(position: Int) : Dessert {
        return dessertList[position]
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DishViewHolder {
        val viewLayout = LayoutInflater.from(parent.context).inflate(R.layout.dessert_item, parent, false)
        return DishViewHolder(viewLayout, callback)
    }

    override fun getItemCount(): Int {
        return dessertList.size
    }

    override fun onBindViewHolder(holder: DishViewHolder, position: Int) {
        val currentDish = dessertList[position]
        holder.dessertName.text = currentDish.dessertName
        holder.dessertImage.setImageResource(currentDish.dessertImgId)
    }
}