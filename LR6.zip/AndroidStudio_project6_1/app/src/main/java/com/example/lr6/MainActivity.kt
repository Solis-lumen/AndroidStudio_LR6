package com.example.lr6

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity(), DessertAdapter.ViewHolderCheckboxListener {
    private lateinit var dessertAdapter: DessertAdapter
    private var selectedDesserts: ArrayList<Dessert> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Setup RecyclerView
        val recyclerView: RecyclerView = findViewById(R.id.myRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val desserts = arrayListOf(
            Dessert("Cake", R.drawable.cake),
            Dessert("Ice cream", R.drawable.ice_cream),
            Dessert("Doughnut", R.drawable.doughnut),
            Dessert("Apple stroudel", R.drawable.apple_stroudel),
            Dessert("Panna cotta", R.drawable.panna_cotta),
            Dessert("Cheesecake", R.drawable.cheesecake),
            Dessert("Tiramisu", R.drawable.tiramisu),
            Dessert("Brownie", R.drawable.brownie)
        )

        dessertAdapter = DessertAdapter(desserts)
        dessertAdapter.callback = this // Set the callback to handle checkbox selections
        recyclerView.adapter = dessertAdapter

        val spinner: Spinner = findViewById(R.id.mySpinner)
        val items = arrayOf("Desserts", "Beverages", "Main courses")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        spinner.adapter = adapter
    }

    // Callback implementation for checkbox listener
    override fun onCheckedChange(position: Int, isChecked: Boolean) {
        dessertAdapter.getDessertByPosition(position).isSelected = isChecked
    }

    fun buttonOrderClick(view: View) {
        selectedDesserts.clear()
        selectedDesserts.addAll(dessertAdapter.dessertList.filter { it.isSelected })

        // Передаємо вибрані десерти в OrderDessert активність
        val intent = Intent(this, OrderDessert::class.java)
        intent.putParcelableArrayListExtra("selectedDesserts", selectedDesserts)
        startActivity(intent)
    }

    fun buttonDemoScrollViewClick(view: View) {
        val intent = Intent(this, ScrollViewDemoActivity::class.java)
        startActivity(intent)
    }
}
